import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/db"
import { createNotification, notifyStifin } from "@/lib/notifications"

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession()
    if (!session || session.role !== "ADVERTISER") {
      return NextResponse.json({ error: "Hanya Advertiser yang dapat menjadwalkan" }, { status: 403 })
    }

    const { id } = await params

    const adRequest = await db.adRequest.findUnique({
      where: { id },
      include: { promotor: true },
    })

    if (!adRequest) {
      return NextResponse.json({ error: "Pengajuan tidak ditemukan" }, { status: 404 })
    }

    if (adRequest.status !== "KONTEN_SELESAI") {
      return NextResponse.json({ error: "Konten belum selesai, tidak dapat dijadwalkan" }, { status: 400 })
    }

    const updated = await db.adRequest.update({
      where: { id },
      data: { status: "IKLAN_BERJALAN" },
      include: { promotor: true },
    })

    // Notify promotor
    await createNotification(
      adRequest.promotorId,
      "Iklan Sedang Berjalan",
      `Iklan Anda untuk ${adRequest.city} sudah dijadwalkan dan sedang berjalan.`,
      "AD_RUNNING",
      id
    )

    await notifyStifin(
      "Iklan Dijadwalkan",
      `Iklan untuk ${adRequest.city} oleh ${adRequest.promotor.name} sudah dijadwalkan.`,
      "AD_RUNNING"
    )

    return NextResponse.json(updated)
  } catch (error) {
    console.error("Schedule error:", error)
    return NextResponse.json({ error: "Gagal menjadwalkan" }, { status: 500 })
  }
}
