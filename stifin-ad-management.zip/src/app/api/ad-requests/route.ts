import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/db"
import { autoSelectBriefType, generateBriefContent } from "@/lib/brief-templates"
import { createNotification, notifyRole, notifyStifin } from "@/lib/notifications"

export async function GET(req: Request) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const city = searchParams.get("city")
    const status = searchParams.get("status")

    const where: any = {}

    if (session.role === "PROMOTOR") {
      where.promotorId = session.id
    }

    if (city) {
      where.city = { contains: city, mode: "insensitive" }
    }

    if (status) {
      where.status = status
    }

    const adRequests = await db.adRequest.findMany({
      where,
      include: {
        promotor: { select: { id: true, name: true, email: true, city: true } },
        adReport: true,
        promotorResult: true,
      },
      orderBy: { createdAt: "desc" },
    })

    return NextResponse.json(adRequests)
  } catch (error) {
    console.error("GET ad-requests error:", error)
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session || session.role !== "PROMOTOR") {
      return NextResponse.json({ error: "Hanya Promotor yang dapat membuat pengajuan" }, { status: 403 })
    }

    const { city, startDate, durationDays, dailyBudget } = await req.json()

    if (!city || !startDate || !durationDays || !dailyBudget) {
      return NextResponse.json({ error: "Semua field wajib diisi" }, { status: 400 })
    }

    const totalBudget = dailyBudget * durationDays
    const ppn = Math.round(totalBudget * 0.11)
    const totalPayment = totalBudget + ppn

    const startDateObj = new Date(startDate)
    const briefType = autoSelectBriefType()
    const briefContent = generateBriefContent(briefType, city, startDateObj)

    const adRequest = await db.adRequest.create({
      data: {
        city,
        startDate: startDateObj,
        durationDays,
        dailyBudget,
        totalBudget,
        ppn,
        totalPayment,
        briefType,
        briefContent,
        promotorId: session.id,
      },
      include: {
        promotor: { select: { name: true } },
      },
    })

    // Notify konten kreator and advertiser
    await notifyRole(
      "KONTEN_KREATOR",
      "Pengajuan Iklan Baru",
      `${adRequest.promotor.name} dari ${city} mengajukan iklan. Menunggu bukti pembayaran.`,
      "AD_REQUEST",
      adRequest.id
    )

    await notifyRole(
      "ADVERTISER",
      "Pengajuan Iklan Baru",
      `${adRequest.promotor.name} dari ${city} mengajukan iklan. Menunggu pembayaran & konten.`,
      "AD_REQUEST",
      adRequest.id
    )

    await notifyStifin(
      "Pengajuan Iklan Baru",
      `Promotor ${adRequest.promotor.name} dari ${city} mengajukan iklan senilai Rp ${totalPayment.toLocaleString("id-ID")}`,
      "AD_REQUEST"
    )

    return NextResponse.json(adRequest, { status: 201 })
  } catch (error) {
    console.error("POST ad-requests error:", error)
    return NextResponse.json({ error: "Gagal membuat pengajuan" }, { status: 500 })
  }
}
